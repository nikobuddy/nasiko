<!-- thank_you.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Thank You</title>
</head>
<body>
    <h2>Thank you for submitting your response!</h2>
    <!-- Add any additional content or links as needed -->
</body>
</html>
